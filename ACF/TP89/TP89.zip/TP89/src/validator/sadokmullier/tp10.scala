package validator.sadokmullier
import bank._

object Code_Numeral {

def integer_of_nat(x0: Nat.nat): BigInt = x0 match {
  case Nat.Nata(x) => x
}

} /* object Code_Numeral */

//object Nat {
//
//abstract sealed class nat
//final case class Nata(a: BigInt) extends nat
//
//def less_nat(m: nat, n: nat): Boolean =
//  Code_Numeral.integer_of_nat(m) < Code_Numeral.integer_of_nat(n)
//
//def zero_nat: nat = Nata(BigInt(0))
//
//def equal_nat(m: nat, n: nat): Boolean =
//  Code_Numeral.integer_of_nat(m) == Code_Numeral.integer_of_nat(n)
//
//def less_eq_nat(m: nat, n: nat): Boolean =
//  Code_Numeral.integer_of_nat(m) <= Code_Numeral.integer_of_nat(n)
//
//} /* object Nat */

object tp89 {

abstract sealed class etat
final case class Validee() extends etat
final case class EnCours() extends etat
final case class Annulee() extends etat
final case class PrixProposer() extends etat
final case class PrixDemander() extends etat

abstract sealed class message
final case class Pay(a: (Nat.nat, (Nat.nat, Nat.nat)), b: Nat.nat) extends
  message
final case class Ack(a: (Nat.nat, (Nat.nat, Nat.nat)), b: Nat.nat) extends
  message
final case class Cancel(a: (Nat.nat, (Nat.nat, Nat.nat))) extends message

def equal(x0: (Nat.nat, (Nat.nat, Nat.nat)), x1: (Nat.nat, (Nat.nat, Nat.nat))):
      Boolean
  =
  (x0, x1) match {
  case ((c1, (m1, idT1)), (c2, (m2, idT2))) => 
    bank.HOL.equal(c1, c2) &&
      (bank.HOL.equal(m1, m2) && bank.HOL.equal(idT1, idT2))
}

def export(x0: List[(etat,
                      ((Nat.nat, (Nat.nat, Nat.nat)), (Nat.nat, Nat.nat)))]):
      List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)]
  =
  x0 match {
  case Nil => Nil
  case (Validee(), (tId, (pClient, pMarchand))) :: s =>
    (tId, pClient) :: export(s)
  case (EnCours(), (tId, (pClient, pMarchand))) :: s => export(s)
  case (Annulee(), (tId, (pClient, pMarchand))) :: s => export(s)
  case (PrixProposer(), (tId, (pClient, pMarchand))) :: s => export(s)
  case (PrixDemander(), (tId, (pClient, pMarchand))) :: s => export(s)
}

def annuleOffre(tId: (Nat.nat, (Nat.nat, Nat.nat)),
                 x1: List[(etat,
                            ((Nat.nat, (Nat.nat, Nat.nat)),
                              (Nat.nat, Nat.nat)))]):
      List[(etat, ((Nat.nat, (Nat.nat, Nat.nat)), (Nat.nat, Nat.nat)))]
  =
  (tId, x1) match {
  case (tId, Nil) => List((Annulee(), (tId, (Nat.zero_nat, Nat.zero_nat))))
  case (tId1, (etat, (tId2, (offre, demande))) :: s) =>
    (if (equal(tId1, tId2)) (Annulee(), (tId2, (offre, demande))) :: s
      else (etat, (tId2, (offre, demande))) :: annuleOffre(tId1, s))
}

def offreClient(tId: (Nat.nat, (Nat.nat, Nat.nat)), x: Nat.nat,
                 xa2: List[(etat,
                             ((Nat.nat, (Nat.nat, Nat.nat)),
                               (Nat.nat, Nat.nat)))]):
      List[(etat, ((Nat.nat, (Nat.nat, Nat.nat)), (Nat.nat, Nat.nat)))]
  =
  (tId, x, xa2) match {
  case (tId, x, Nil) =>
    (if (Nat.less_nat(Nat.zero_nat, x))
      List((PrixProposer(), (tId, (x, Nat.zero_nat)))) else Nil)
  case (tId1, x, (etat, (tId2, (pClient, pMarchand))) :: s) =>
    (if (equal(tId1, tId2))
      (etat match {
         case Validee() => (etat, (tId2, (pClient, pMarchand))) :: s
         case EnCours() =>
           (if (Nat.less_nat(pClient, x))
             (if (Nat.less_eq_nat(pMarchand, x))
               (Validee(), (tId2, (x, pMarchand))) :: s
               else (etat, (tId2, (x, pMarchand))) :: s)
             else (etat, (tId2, (pClient, pMarchand))) :: s)
         case Annulee() => (etat, (tId2, (pClient, pMarchand))) :: s
         case PrixProposer() =>
           (if (Nat.less_nat(pClient, x)) (etat, (tId2, (x, pMarchand))) :: s
             else (etat, (tId2, (pClient, pMarchand))) :: s)
         case PrixDemander() =>
           (if (Nat.less_nat(Nat.zero_nat, x))
             (if (Nat.less_eq_nat(pMarchand, x))
               (Validee(), (tId2, (x, pMarchand))) :: s
               else (EnCours(), (tId2, (x, pMarchand))) :: s)
             else (etat, (tId2, (pClient, pMarchand))) :: s)
       })
      else (etat, (tId2, (pClient, pMarchand))) :: offreClient(tId1, x, s))
}

def offreMarchand(tId: (Nat.nat, (Nat.nat, Nat.nat)), x: Nat.nat,
                   xa2: List[(etat,
                               ((Nat.nat, (Nat.nat, Nat.nat)),
                                 (Nat.nat, Nat.nat)))]):
      List[(etat, ((Nat.nat, (Nat.nat, Nat.nat)), (Nat.nat, Nat.nat)))]
  =
  (tId, x, xa2) match {
  case (tId, x, Nil) =>
    (if (Nat.less_nat(Nat.zero_nat, x))
      List((PrixDemander(), (tId, (Nat.zero_nat, x)))) else Nil)
  case (tId1, x, (etat, (tId2, (pClient, pMarchand))) :: s) =>
    (if (equal(tId1, tId2))
      (etat match {
         case Validee() => (etat, (tId2, (pClient, pMarchand))) :: s
         case EnCours() =>
           (if (Nat.less_nat(x, pMarchand))
             (if (Nat.less_eq_nat(x, pClient))
               (Validee(), (tId2, (pClient, x))) :: s
               else (etat, (tId2, (pClient, x))) :: s)
             else (etat, (tId2, (pClient, pMarchand))) :: s)
         case Annulee() => (etat, (tId2, (pClient, pMarchand))) :: s
         case PrixProposer() =>
           (if (Nat.less_eq_nat(Nat.zero_nat, x))
             (if (Nat.less_eq_nat(x, pClient))
               (Validee(), (tId2, (pClient, x))) :: s
               else (EnCours(), (tId2, (pClient, x))) :: s)
             else (etat, (tId2, (pClient, pMarchand))) :: s)
         case PrixDemander() =>
           (if (Nat.less_nat(x, pMarchand) && Nat.less_nat(Nat.zero_nat, x))
             (etat, (tId2, (pClient, x))) :: s
             else (etat, (tId2, (pClient, pMarchand))) :: s)
       })
      else (etat, (tId2, (pClient, pMarchand))) :: offreMarchand(tId1, x, s))
}

def traiterMessage(x0: message,
                    bdd: List[(etat,
                                ((Nat.nat, (Nat.nat, Nat.nat)),
                                  (Nat.nat, Nat.nat)))]):
      List[(etat, ((Nat.nat, (Nat.nat, Nat.nat)), (Nat.nat, Nat.nat)))]
  =
  (x0, bdd) match {
  case (Pay(tId, x), bdd) => offreClient(tId, x, bdd)
  case (Ack(tId, x), bdd) => offreMarchand(tId, x, bdd)
  case (Cancel(tId), bdd) => annuleOffre(tId, bdd)
}

} /* object tp89 */
