package bank;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import bank.action.SendCancel;
import bank.action.SendClient;
import bank.action.SendMerchant;
import bank.observer.Observer;
import bank.observer.Subject;

public class Ihm extends JFrame implements Observer {

    // composants de la fenetre

    private JLabel lc1 = new JLabel("Client id");
    private JLabel lc2 = new JLabel("Merchant id");
    private JLabel lc3 = new JLabel("Transaction id");
    private JLabel lc4 = new JLabel("Amount");

    private JLabel lm1 = new JLabel("Cient id");
    private JLabel lm2 = new JLabel("Merchant id");
    private JLabel lm3 = new JLabel("Transaction id");
    private JLabel lm4 = new JLabel("Amount");
    private JLabel none1 = new JLabel(" ");
    private JLabel none2 = new JLabel(" ");

    private JLabel ltrans = new JLabel("Transactions accepted by the Bank");
    private JLabel ltrace = new JLabel("Full messages trace");

    private JTextField zoneC1;
    private JTextField zoneC2;
    private JTextField zoneC3;
    private JTextField zoneC4;

    private JTextField zoneM1;
    private JTextField zoneM2;
    private JTextField zoneM3;
    private JTextField zoneM4;

    private JTextArea zoneB;
    private JTextArea zoneTrace;

    private JPanel panelExt;
    private JPanel panelCM;
    private JPanel panelB;
    private JPanel panelTrace;
    private JPanel panelButtonM;

    private JButton buttonC;
    private JButton buttonM;
    private JButton buttonCancel;

    private Bank bank = new Bank(new validator.sadokmullier.ConcreteValidator());

    public Ihm() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Transaction Simulator");

        this.buttonC = new JButton(new SendClient("Client sends...", this));
        this.buttonM = new JButton(new SendMerchant("Merchant sends...", this));
        this.buttonCancel = new JButton(new SendCancel("Merchant cancels", this));

        this.zoneC1 = new JTextField(5);
        this.zoneC2 = new JTextField(5);
        this.zoneC3 = new JTextField(5);
        this.zoneC4 = new JTextField(5);

        this.zoneM1 = new JTextField(5);
        this.zoneM2 = new JTextField(5);
        this.zoneM3 = new JTextField(5);
        this.zoneM4 = new JTextField(5);

        this.zoneB = new JTextArea("", 10, 30);
        this.zoneB.setEditable(false);
        this.zoneTrace = new JTextArea("", 10, 30);
        this.zoneTrace.setEditable(false);

        // sauts de lignes automatiques dans les zoneB et zoneTrace
        this.zoneB.setLineWrap(true);
        this.zoneTrace.setLineWrap(true);
        this.zoneB.setWrapStyleWord(true);
        this.zoneTrace.setWrapStyleWord(true);

        this.panelExt = new JPanel();
        this.panelCM = new JPanel();
        this.panelB = new JPanel();
        this.panelTrace = new JPanel();
        this.panelButtonM = new JPanel();

        // panel.setLayout(new FlowLayout()); // avec une m�thode de placement automatique

        this.panelExt.setLayout(new GridLayout(3, 1));
        this.panelCM.setLayout(new GridLayout(4, 5));
        this.panelB.setLayout(new GridLayout(2, 1));
        this.panelTrace.setLayout(new GridLayout(2, 1));
        this.panelButtonM.setLayout(new GridLayout(2, 1));

        this.panelCM.add(this.lc1);
        this.panelCM.add(this.lc2);
        this.panelCM.add(this.lc3);
        this.panelCM.add(this.lc4);
        this.panelCM.add(this.none1);
        this.panelCM.add(this.zoneC1);
        this.panelCM.add(this.zoneC2);
        this.panelCM.add(this.zoneC3);
        this.panelCM.add(this.zoneC4);

        this.panelCM.add(this.buttonC);

        this.panelCM.add(this.lm1);
        this.panelCM.add(this.lm2);
        this.panelCM.add(this.lm3);
        this.panelCM.add(this.lm4);
        this.panelCM.add(this.none2);

        this.panelCM.add(this.zoneM1);
        this.panelCM.add(this.zoneM2);
        this.panelCM.add(this.zoneM3);
        this.panelCM.add(this.zoneM4);

        this.panelButtonM.add(this.buttonM);
        this.panelButtonM.add(this.buttonCancel);
        this.panelCM.add(this.panelButtonM);

        this.panelB.add(this.ltrans);
        this.panelB.add(this.zoneB);

        this.panelTrace.add(this.ltrace);
        this.panelTrace.add(this.zoneTrace);

        this.panelExt.add(this.panelCM);
        this.panelExt.add(this.panelB);
        this.panelExt.add(this.panelTrace);

        // on associe le panel � la fen�tre d'Ihm
        this.setContentPane(this.panelExt);
        this.bank.addObserver(this);
    }

    public void sendClient() {
        try {
            this.bank.traiter(new ExtPay(Integer.parseInt(this.zoneC1.getText()), Integer.parseInt(this.zoneC2.getText()), Integer.parseInt(this.zoneC3.getText()),
                    Integer.parseInt(this.zoneC4.getText())));
        } catch (NumberFormatException e) {
        }
    }

    public void sendMerchant() {
        try {
            this.bank.traiter(new ExtAck(Integer.parseInt(this.zoneM1.getText()), Integer.parseInt(this.zoneM2.getText()), Integer.parseInt(this.zoneM3.getText()),
                    Integer.parseInt(this.zoneM4.getText())));
        } catch (NumberFormatException e) {
        }
    }

    public void cancel() {
        try {
            this.bank.traiter(new ExtCancel(Integer.parseInt(this.zoneM1.getText()), Integer.parseInt(this.zoneM2.getText()), Integer.parseInt(this.zoneM3.getText())));
        } catch (NumberFormatException e) {
        }
    }

    public void myNotify(Subject s) {
        this.zoneB.setText(((Bank) s).transToString());
        this.zoneTrace.setText(((Bank) s).traceToString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {

            public void run() {
                Ihm ihm = new Ihm();
                ihm.setSize(700, 350);
                ihm.setVisible(true);
                ihm.pack();
            }
        });
    }
}
