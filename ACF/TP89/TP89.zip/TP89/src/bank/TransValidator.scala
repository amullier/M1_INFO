package bank


/* The Scala Trait to implement */ 
trait TransValidator {
	def process(e: message)
	def getValidTrans: List[((bank.Nat.nat, (bank.Nat.nat, bank.Nat.nat)),bank.Nat.nat)]= List()
	def authors: String
}